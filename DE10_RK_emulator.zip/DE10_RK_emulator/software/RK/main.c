﻿/*
              *****************************************************************************
              *  Copyright (C) by Reinhard Heuberger  , www.pdp11gy.com                   *
              *                                                                           *
              *  All rights reserved.                                                     *
              *                                                                           *
              *  Redistribution and use in source and binary forms, with or without       *
              *  modification, are permitted provided that the following conditions       *
              *  are met:                                                                 *
              *                                                                           *
              *  1. Redistributions of source code must retain the above copyright        *
              *     notice, this list of conditions and the following disclaimer.         *
              *  2. Redistributions in binary form must reproduce the above copyright     *
              *     notice, this list of conditions and the following disclaimer in the   *
              *     documentation and/or other materials provided with the distribution.  *
              *  3. Neither the name of the author nor the names of its contributors may  *
              *     be used to endorse or promote products derived from this software     *
              *     without specific prior written permission.                            *
              *                                                                           *
              *****************************************************************************
                   RK05 Emulator for SoC HPS FPGA-environment based on DE10-Nano board
                                        Version V.1.0

                     by: Reinhard Heuberger , www.PDP11GY.com, info@pdp11gy.com


                                 Data - Structure and Mapping:
                
        Output controll I/O @ pio-1 = rk_out
        rk_out[0]   Interface enable
        rk_out[2]   Address accepted
        rk_out[4]   R/W/S Ready (Read, Write, or Seek Ready)
        rk_out[5]   File Ready
        rk_out[6]   Write Protect Status
        rk_out[7]   Write Check
        rk_out[15]  Led-Pattern controll
        rk_out[8]   DEBUG mode, connect GPIO1, Pin 35 to PIN 20
    
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include "hwlib.h"
#include "socal/socal.h"
#include "socal/hps.h"
#include "socal/alt_gpio.h"
#include "hps_0.h"
#include <signal.h>
//
//
void init_HW(void);
void startup_leds(void);
void PRESET_one_SECTOR(void);
void make_rk_structure_in_ram(void);
void WRITE_drive_to_FPGA(int point_to_track);
void READ_drive_from_FPGA(int point_to_track);
void acknowledge(void);
//
void WRITE_to_SD_Card(void);
void write_DEC(void);
void write_DSK(void);
void READ_from_SD_Card(void);
void read_DEC(void);
void read_DSK(void);
void make_data_CRC(void);
//
void RAM_align(void);
//
//
typedef unsigned char byte;
//
#define HW_REGS_BASE ( ALT_STM_OFST )             // axi_lw
#define HW_REGS_SPAN ( 0x04000000 )               // Bridge span
#define HW_REGS_MASK ( HW_REGS_SPAN - 1 )
#define ALT_AXI_FPGASLVS_OFST (0xC0000000)        // axi_master
#define HW_FPGA_AXI_SPAN (0x40000000)             // Bridge span
#define HW_FPGA_AXI_MASK ( HW_FPGA_AXI_SPAN - 1 )
//
#define CYL_size 6528            // One cylinder size,       16Bit words
#define DPR_size 5760            // Dual-Portet-RAM size, 16Bit words
#define RK05_size 255            // RK05 = 256 cylinder ( 0 - 256 )
//
#define RAMi 12000000             // Used RAM-Size integer
#define RAMs 24000000             // Used RAM-Size short integer
#define RAMb 48000000             // Used RAM-Size byte
#define RL0_base 0                // Byte: 0
//
#define SEC_size_c 544            // byte:    Sector size, 8Bit
#define SEC_size_i 272            // integer: Sector size, including header/crc/servo 16Bit
#define SEC_size_l 136            // long:    Sector size, including header/crc/servo 32Bit
#define sec_per_track 12          // number of sectores in one track
#define TRUE  1
#define FALSE 0
//
// 4 Unit-Size + Base-addresses 16bit in RAM for the RL-Units
#define RAMi 12000000             // Used RAM-Size integer
#define RAMs 24000000             // Used RAM-Size short integer
#define RAMb 48000000             // Used RAM-Size byte
#define RK0_base 0                // Byte: 0
#define RK1_base 6000000          // Byte: 12000000
#define RK2_base 12000000         // Byte: 18000000
#define RK3_base 18000000         // Byte: 36000000
//
//
/*        *********************** Global Definitions **********************        */

//
//++++++++++++++++++++++++++++++++++ UNION's +++++++++++++++++++++++++++++++++++++++++++++++++++++++++
union rkd {                                     // ****** one RK05 sector *************
       unsigned char  rkc[600];                 // Access to one Sector via 600 bytes or
       unsigned short rki[300];                 // 300 16Bit words.
       unsigned int   rkl[150];
};
union  rkd SECTOR __attribute__ ((aligned(4)));   // define a union of type SECTOR
union  rkd *u_rxptr;                              // pointer to union.
//------------------------------------------------------------------------------------------------------
union rkt {
       unsigned char  rk_drive_c[RAMb];           // ******* RL02 Structure @ RAM/=union ********
       unsigned short rk_drive_i[RAMs];           // Virtual access to 512 cylinders(head 0 and 1)
       unsigned int   rk_drive_l[RAMi];           // 2* 40 sectors = 11520 16 bit * 512 = 5898240/unit
};
union  rkt RKDRIVE __attribute__ ((aligned(4)));  // define a union of type RXDRIVE
union  rkt *u_rk_drive_ptr; 
//union  rlt RLDRIVE __attribute__ ((aligned(4)));  // define a union of type RLDRIVE
//union  rlt *u_rl02_drive_ptr;                     // pointer to union                      // pointer to union
//------------------------------------------------------------------------------------------------------
int fd;                                           // Hold FPGA address
void *virtual_base;                               // Virtual axi-lw addr that maps to physical
void *axi_virtual_base;                           // Virtual axi-master addr that maps to physical
void *PIO_0_addr;                                 // PIO-0 address
void *PIO_1_addr;                                 // PIO-1 address
void *DPR;                                        // #1, Dual Ported Ram address
void *DPR_addr;                                   // #1, Dual Ported Ram address with AXI-Master
//void *UART0;                                    // UART_0 address
//------------------------------------------------------------------------------------------------------
//
// Byte sector = 544 mal 12 mal 2(heads) , mal 256(cylinder)  = 3342336
int SDRAM                   =  3342336;           // Used bytes in RAM for one RK05-unit
unsigned short int data_start =     14;           // + 14, = +preamble=13 +Header=1
unsigned short int data_CRC =      270;           // + 128
unsigned short int RK_unit  =        0;           // configured  RL unit(s) ( Statisch )
unsigned short int RK_Nr    =        0;           // current used Drive Number
unsigned short int RK_Nr_old    =    0;           // Used Drive Number before
unsigned short int RK_match =        0;           // Match for RL Unit binary notation
unsigned short int RK_match_old =    0;           // Used Match before
//
int Cylinder_nr=0;                                // Cylinder number , 0 - 255 ( RL02 )
int rk0_cnr=0, rk1_cnr=0, rk2_cnr=0, rk3_cnr=0;
//
int Old_Cyl_nr = 0;                              // Cylinder address SAVE
int rk0_Old_Cyl_nr=0, rk1_Old_Cyl_nr=0, rk2_Old_Cyl_nr=0, rk3_Old_Cyl_nr=0;
//
int Cylinder_nr_diff = 0;
unsigned short MAXCYL       = 255;                // 8 bit cylinder address = 0 to 255 
//
int BASE = RK0_base;
int DEST = RK1_base;
int rkBASE;
int RAM_Address = RK0_base;
int Old_RAM_Address = RK0_base;
int unit_base;
//
short int mode     =0;
//
unsigned char DEBUG=1;                            // DEBUG PURPOSE
unsigned char OFFLINE=0;                          // online/offline mode
unsigned char OFFMODE=0;                          // full/simple offline mode
unsigned char format=0;                           // Init(format) disk set
unsigned char rk0=0;                              // Unit 0
unsigned char rk1=0;                              // Unit 1
unsigned char rk2=0;                              // Unit 2
unsigned char rk3=0;                              // Unit 3
unsigned char noDECfile=0;
unsigned char makeCRC = 0;                        // Build checksum or CRC
//
unsigned char RK_drive_nr_changed=0;              // Flag to indicate a RL-drive UNIT number change was done
//
unsigned char priwhile = 0;
unsigned char secwhile = 0;
//
unsigned short int head=0, Old_head=0;
unsigned short int rk0_head=0, rk0_Old_head=0;
unsigned short int rk1_head=0, rk1_Old_head=0;
unsigned short int rk2_head=0, rk2_Old_head=0;
unsigned short int rk3_head=0, rk3_Old_head=0;
//

//
char myfile2[80];
char set[20];
char myfile3[80];
//
/*******************************************************************************************************/
//
//
void init_HW(void)
{
  //---------------------------------------------------------------------------------------------------
  // === get FPGA addresses ===
  // Open /dev/mem
  if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
        printf( "ERROR: could not open \"/dev/mem\"...\n" );
  return; }
  //---------------------------------------------------------------------------------------------------
  // Get virtual addr that maps to physical
  virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );
  if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: mmap() failed...\n" );
        close( fd );
  return; }
  axi_virtual_base = mmap( NULL, HW_FPGA_AXI_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, ALT_AXI_FPGASLVS_OFST );
  //----------------------------------------------------------------------------------------------------
  //
  // Get the addresses that maps to the FPGA control 
  PIO_0_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_0_BASE ) 
                                & ( unsigned long)( HW_REGS_MASK ) );
  PIO_1_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_1_BASE )
                                & ( unsigned long)( HW_REGS_MASK ) );
  DPR =  virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + DPR_BASE )
                      & ( unsigned long)( HW_REGS_MASK ) ); 
  DPR_addr =   axi_virtual_base + ( ( unsigned long  )( DPR_BASE ));  // This works with DPR !!!
  //
  if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: mmap() failed...\n" );
        close( fd );
        return; }
  //-----------------------------------------------------------------------------------------------------
  // 
}
//
//
void startup_leds(void)
{
int loop_count;
int led_direction;
int led_mask;
loop_count = 0;
led_mask = 0x01;
led_direction = 0; // 0: left to right direction
    //
    while(loop_count < 3 )  {
      *(uint32_t *)PIO_0_addr = led_mask;
      usleep( 20*1000 );
      if (led_direction == 0){
            led_mask <<= 1;
            if (led_mask == (0x01 << (PIO_0_DATA_WIDTH-1)))
                 led_direction = 1;
        }else{
            led_mask >>= 1;
            if (led_mask == 0x01){ 
                led_direction = 0;
                loop_count++;
            }
        }        
    }
}
//
//
//
void PRESET_one_SECTOR(void) {
/* initialize data for one sector/track  used for test and reference purpose.

   Sector Structure:
   
   Preamble  : 15(octal) = 13 16bit word of Zero
   SYNC Bit  :  1 Bit, just include it in preamble
   Header    :  single 16-bit word containing the aktual Cylinder adrress.
   Data      :  256 (decimal) data words
   Checksum  :  single 16-bit word that is the checksum of all 256 data words.
   POSTAMBLE :  single 16-bit word used as a buffer.

                Summ:  272 words ( 0-271 ) , Data: 256 words
                  datastart = @ 14 , CRC(checksum) = @ 270
*/
    int i;
    unsigned short checksum;
    unsigned short offset = 14;
    //
    unsigned short mysector[]=
    {   0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,   // Preamble 00-07  
        0x0000, 0x0000, 0x0000, 0x0000, 0x8000,                           // Preamble 07-12 + sync
        0x0000,                                                           // Header @ 13
        //  offset = 14 : Data-Area = 256 words = 2 times pattern
        0x0000, 0x0000,                                                   //  Data 00-01
        0xFF00, 0xFF00, 0xFF00, 0xFF00, 0xFF00, 0x0000, 0x0000, 0x0000,   //  Data 02-09
        0x3333, 0x3333, 0x3333, 0x3333, 0x3333, 0x0000, 0x0000, 0x5500,   //  Data 10-17
        0x5555, 0x5555, 0x5555, 0x5555, 0x0055, 0x0000, 0x0000, 0x9249,   //  Data 18-25
        0x4924, 0x2492, 0x9249, 0x0024, 0x0000, 0x0000, 0x9123, 0x23DC,   //  Data 26-33
        0xDC91, 0x9123, 0x00DC, 0x0000, 0x0000, 0x8080, 0x8080, 0x8080,   //  Data 34-41
        0x8080, 0x8080, 0x0000, 0x0000, 0xE700, 0xF39C, 0x9CE7, 0xE7F3,   //  Data 42-49
        0xF39C, 0x0000, 0x0000, 0x6300, 0xF18C, 0x8C63, 0x63F1, 0xF18C,   //  Data 50-57
        0x0000, 0x0000, 0x7F00, 0x7F7F, 0x7F7F, 0x7F7F, 0x7F7F, 0x007F,   //  Data 58-65
        0x0000, 0x0000, 0x0D0A, 0x5453, 0x4C45, 0x204C, 0x4944, 0x2052,   //  Data 66-73
        0x4F56, 0x2052, 0x5345, 0x4920, 0x5453, 0x4B20, 0x4952, 0x4745,   //  Data 74-81
        0x5520, 0x444E, 0x4B20, 0x4945, 0x454E, 0x2052, 0x4547, 0x5448,   //  Data 82-89
        0x4820, 0x4E49, 0x0D0A, 0x2020, 0x4D49, 0x4741, 0x4E49, 0x2045,   //  Data 90-97
        0x5449, 0x4920, 0x2053, 0x4157, 0x2052, 0x4E41, 0x2044, 0x4F4E,   //  Data 98-105
        0x4F42, 0x5944, 0x4720, 0x414F, 0x2053, 0x4854, 0x5245, 0x2045,   //  Data 106-113
        0x0A20, 0xFF0D, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF,   //  Data 114-121
        0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x0000,                   //  Data 122-127
        //
        0x000,                                                           //  128/256 = checksum
        //  
        0xFFFF,                                                           //  129 =           
        0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,   //  130-137=Zero
        0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,   //  138-145=Zero
        0x0000, 0x0000, 0x0000, 0x0000, 0x0000 };                         //  146-150=Zero
    //
    //
    for (i = 0; i < SEC_size_i ; i++ ) { SECTOR.rki[i] = 0x0000;}                  // clear buffer 
    // 
    for (i = 0; i < offset; i++ ){ 
        SECTOR.rki[i] = mysector[i];                                               // Header
    }
    for (i = offset; i < offset+128; i++ ){
        SECTOR.rki[i] = mysector[i];                                               // first 128 words
        checksum = checksum + SECTOR.rki[i];
    }
    offset = i;
    for (i = offset; i < offset+128; i++ ){
        SECTOR.rki[i] = mysector[i-142];                                           // second 128 words
        checksum = checksum + SECTOR.rki[i];
    }
    SECTOR.rki[i]   = checksum;                                                    // Checksum
    SECTOR.rki[i+1] = 0x0000;                                                      // POSTAMBLE
}
//
//
void make_rk_structure_in_ram(void) {
    // 
    unsigned short int RK_sector, RK_cylinder, cyl_offset=13, i;
    int nr    = 0;
    //
    for (RK_cylinder = 0; RK_cylinder < MAXCYL; RK_cylinder++ ) {
        // 
        for (RK_sector = 0; RK_sector < sec_per_track ; RK_sector++ ) {       // construct  sectors @ head 0
            SECTOR.rki[cyl_offset] = RK_cylinder;                             // set cylinder
            //
            for(i = 0; i< SEC_size_i; i++) {
                RKDRIVE.rk_drive_i[nr+i] = SECTOR.rki[i];                     // Copy track into RAM                
            }           
        nr = nr + SEC_size_i;      
        }
        //
        //
        for (RK_sector = 0; RK_sector < sec_per_track; RK_sector++ ) {       // construct  sectors @ head 1
            SECTOR.rki[cyl_offset] = RK_cylinder;                            // set cylinder
            //
            for(i = 0; i< SEC_size_i; i++) {
                RKDRIVE.rk_drive_i[nr+i] = SECTOR.rki[i];                    // Copy track into RAM                
            }           
        nr = nr + SEC_size_i;      
        }       
    }
}
//
//
void WRITE_drive_to_FPGA(int point_to_track){
  //
  // FPGA Dual-Ported-RAM size: 40 x SEC_size 16bit words = 
  // This routine writes one sector from union RLDRIVE.rl_drive_i to FPGA/DP-RAM
  //                               ##################
  //                               ### RAM-->FPGA ###
  //                               ##################
  //
  //if((DEBUG == TRUE) & (OFFLINE == TRUE)){
  //    printf("\n\r>>> RAM -> FPGA/DPR @Base: %d  = Track-Address: %d \n\r", BASE, point_to_track); }
  //
  memcpy((void *)(DPR_addr), &RKDRIVE.rk_drive_i[point_to_track], SEC_size_c * sec_per_track );
  //
}
//
//
void READ_drive_from_FPGA(int point_to_track){
    //
    // FPGA Dual-Ported-RAM size: 40 x SEC_size 16bit words = 
    // This routine reads one sector from FPGA/DP-RAM into union RLDRIVE.rl_drive_i
    //                               ##################
    //                               ### FPGA-->RAM ###
    //                               ##################
    //
    //if((DEBUG == TRUE) & (OFFLINE == TRUE)){
    //   printf("\n\r<<< RAM <- FPGA/DPR @Base: %d  = Track-Address: %d \n\r", BASE, point_to_track); }
    //
    //
    memcpy(&RKDRIVE.rk_drive_i[point_to_track], (void *)(DPR_addr), SEC_size_c * sec_per_track );
}
//
//
void acknowledge(void){
  // Terminate Seek-cycle,  sending a acknowledge pulse  @ O_ctrl[2]
  *(uint32_t *)PIO_1_addr = (mode=mode|0x0004);
  usleep( 100 );
  *(uint32_t *)PIO_1_addr = (mode=mode&~0x0004);
}
//
//
void WRITE_to_SD_Card(void){
  //
  // RK05: dec-format : 3.338752 Bytes
  //       dsk-format : 3.145728 Bytes
  //
  int k=0;
  unsigned char conf=0;
  //
  //
  for(k=0; k<4; k++) {                                         // files for 4 units
        switch(k) {
        case 0:
            if((rk0 == TRUE) | (format == TRUE)){ 
               conf=1;
               //strcat( myfile2, "_0" );strcat( myfile2,set );
               myfile2[5]='0';
            } else { 
               conf=0;
            }
            RK_Nr = 0;
            unit_base=RK0_base; break;
        case 1:
            if((rk1 == TRUE) | (format == TRUE)){ 
               conf=1;
               //strcat( myfile2, "_1" );strcat( myfile2,set );
               myfile2[5]='1';
            } else { 
               conf=0;
            }
            RK_Nr = 1;
            unit_base=RK1_base; break;
        case 2:
            if((rk2 == TRUE) | (format == TRUE)){ 
               conf=1;
               //strcat( myfile2, "_2" );strcat( myfile2,set );
               myfile2[5]='2';
            } else { 
               conf=0;
            }
            RK_Nr = 2;
            unit_base=RK2_base; break;
        case 3:
            if((rk3 == TRUE) | (format == TRUE)){
               conf=1;
               //strcat( myfile2, "_3" );strcat( myfile2,set ); 
               myfile2[5]='3';
            } else { 
               conf=0;
            }
            RK_Nr = 3;
            unit_base=RK3_base; break;
        }
        if(conf == TRUE){
            printf ("\n\r+----------------------------------------------------------------------+");
            myfile2[8]='e';
            myfile2[9]='c';
            printf ("\n\r|    Unit number: %d  ", RK_Nr);
            printf (">  Write to file %s ", myfile2);
            //-------------
            write_DEC();
            //-------------
            myfile2[8]='s';
            myfile2[9]='k';
            //-------------
            printf ("and %s    |\n\r", myfile2);
            write_DSK();
            printf ("+----------------------------------------------------------------------+\r\n");
        } else {
            printf ("\n\r    Unit number: %d  not configured, will be skipped \n\r", RK_Nr);
        }
    }
}
//
//
void write_DEC(void) {
    //
    // Write RK05 memory-image to the .DEC file
    //
    FILE    *fptr;
    int loops = SDRAM/20480, i=0, j=0;
    //unsigned short dot=0, led=0x8000;
    //
    fptr = fopen(myfile2, "wb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/write image file %s \n\r", myfile2);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    i=unit_base *2;                                                              // !!! *2, da byte
    for(j=0; j<loops; j++) {
        fwrite((void*)&RKDRIVE.rk_drive_c[i], 1 , 20480, fptr ); 
        i=i+20480;                                                         //In Steps of 20480 byte
    }       
    fwrite((void*)&SECTOR.rkc[0], 1, 512, fptr );
    //
    fclose(fptr);   
}
//
//
void write_DSK(void) {
    // SEC_size_c: 544 byte
    // Write RL memory image to the .DSK file
    //
    FILE    *fptr = 0;
    byte sectorbuf[544];
    int DATAOFFS = 28;                             // RK05: Data start @ 16, byte 32
    int loops = SDRAM/544, i=0, j=0, l=0;
    //
    fptr = fopen(myfile2, "wb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/write image file %s \n\r", myfile2);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    i=unit_base *2; 
    for(j=0; j<loops; j++) {
        //
        for(l = 0; l< SEC_size_c; l++) {                           // copy
            sectorbuf[l] = RKDRIVE.rk_drive_c[i+l];                // sector
        }
        fwrite(sectorbuf + DATAOFFS, 1, 512, fptr);
        i=i+544;        
    }
    fclose(fptr);       
}
//
//
void READ_from_SD_Card(void){
    //
    // RL01: 5,62 MB ( 5.898.752 Bytes)
    // RL02: 11,2 MB (11.796.992 Bytes)
    //
    int k=0;
    unsigned char conf=0;
    // Preset Memory in Case of reading .DSK files
    BASE = RL0_base;
    make_rk_structure_in_ram();
    memcpy(&RKDRIVE.rk_drive_i[RK1_base], &RKDRIVE.rk_drive_i[BASE], SDRAM );
    memcpy(&RKDRIVE.rk_drive_i[RK2_base], &RKDRIVE.rk_drive_i[BASE], SDRAM );
    memcpy(&RKDRIVE.rk_drive_i[RK3_base], &RKDRIVE.rk_drive_i[BASE], SDRAM );
    //
    fflush(stdout);
    for(k=0; k<4; k++) {
        switch(k) {
        case 0:
            if(rk0 == TRUE){ 
                conf=1;
                //strcat( myfile2, "_0" );strcat( myfile2,set );
                myfile2[5]='0';
            }else{ 
                conf=0;
            }
            RK_Nr = 0;
            unit_base=RK0_base; break;
        case 1:
            if(rk1 == TRUE){ 
                conf=1; 
                //strcat( myfile2, "_1" );strcat( myfile2,set );
                myfile2[5]='1';
            }else{ 
               conf=0;
            }
            RK_Nr = 1;
            unit_base=RK1_base;break;
        case 2:
            if(rk2 == TRUE){ 
                conf=1;
                //strcat( myfile2, "_2" );strcat( myfile2,set );
                myfile2[5]='2';
            }else{ 
               conf=0;
            }
            RK_Nr = 2;
            unit_base=RK2_base; break;
        case 3:
            if(rk3 == TRUE){
                conf=1;
                //strcat( myfile2, "_3" );strcat( myfile2,set );
                myfile2[5]='3';
            }else{ 
               conf=0;
            }
            RK_Nr = 3;
            unit_base=RK3_base; break;
        }
        if(conf == TRUE){
            myfile2[8]='e';
            myfile2[9]='c';
            printf ("\n\r+............................................................................+");
            printf ("\n\r|   Unit number: %d ", RK_Nr);
            printf ("> file %s ", myfile2);
            fflush(stdout);
            //-------------
            read_DEC();
            if(noDECfile == TRUE) {
               //-------------
               myfile2[8]='s';
               myfile2[9]='k';
               //-------------
               printf (" not found, using file %s     |\n\r", myfile2);
               read_DSK();
            } else {
                printf(" used                                   |\r\n");
            }
            printf ("+............................................................................+\n\r");
            //-------------
        }else{
            printf ("\n\r    Unit number: %d  = Not configured \n\r", RK_Nr);
        }
    }
}
//
//
void read_DEC(void) {
    // Read .DEC file 
    FILE    *fptr;
    int loops=SDRAM/20480, i=0, j=0;
    //
    fflush(stdout);
    fptr = fopen(myfile2, "rb");
    if(fptr == NULL) {
        noDECfile = 1;
    } else {
        noDECfile = 0;
        i=unit_base *2;                                                             // !!! *2, da byte
        for(j=0; j<loops; j++) {
            fread((void*)&RKDRIVE.rk_drive_c[i], 1 , 20480, fptr );
            i=i+20480;
        }
        fread((void*)&SECTOR.rkc[0], 1, 512, fptr );
        fclose(fptr);
    }
}
//
//
void read_DSK(void) {
    // Read .DSK file
    FILE    *infile = 0;
    byte sectorbuf[544];
    int loops = SDRAM/544, i=0, j=0, k=0, m=0;
    int DATAOFFS = 28;
    infile = fopen(myfile2, "rb");
    if(infile == NULL) {
        printf ("\n\n\n\r\x07 ERROR open/read image .DSK file %s \n\r", myfile2);
        printf ("\n\r FIX THIS PROBLEM AND RESTART \n\r\n");
        fflush(stdout);
        *(uint32_t *)PIO_1_addr = 0x0000;
        exit(0);
    }
    i=unit_base;
    for(j=0; j<loops; j++) {                  
        fread(sectorbuf , 1, 512, infile);                           // read one sector
        for(m=0; m<512; m++) {
            SECTOR.rkc[m + DATAOFFS] = sectorbuf[m];                 // Copy received sector-buffer to sector
        }
        make_data_CRC();                                             // make Data CRC
        //
        for(k = DATAOFFS; k <= DATAOFFS+256; k++) {       
            RKDRIVE.rk_drive_i[i+k] = SECTOR.rki[k];                  // copy sector to RAM(union)
        }
        i=i+SEC_size_i;
    }
    fclose(infile);
    PRESET_one_SECTOR();
}
//
//
//- calcCRC16r ------------------------------------------------------
unsigned short int calcCRC16r(unsigned short int crc, unsigned short int c, unsigned short int mask)
//
// Note: This smart C-Code was not written by myself.
// Reference: http://www.mikrocontroller.net/topic/12177#2274632
{
  unsigned char i;
  for(i=0;i<8;i++)
  {
    if((crc ^ c) & 1) { crc=(crc>>1)^mask; }
    //if((crc = crc  ^ c) & 1) { crc=(crc>>1)^mask; }
    else crc>>=1;
    c>>=1;
  }
  return (crc);
}
//
void make_data_CRC(void){
/*
  Problem here is: Once is in the Docu that 16bit CRC ( RK8E) is required, 
  other times is that a checksum ( RK11 ) is required. 
*/
    unsigned short int i, MSB, LSB;
    unsigned short int DEVICE_CRC16;
    unsigned short int checksum;
    //
    DEVICE_CRC16 = 0;                          // preset Data-CRC
    checksum     = 0;                          // preset checksum
    //
    if(makeCRC == TRUE ){
        for (i = data_start; i < data_CRC; i++ ){
            MSB = i<<1;      // = i*2
            LSB = MSB + 1;
            DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rkc[MSB],0xA001);
            DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rkc[LSB],0xA001);
        }
        SECTOR.rki[data_CRC] = DEVICE_CRC16;       // SET DATA-CRC
    } else {
        for (i = data_start; i < data_CRC; i++ ){
            checksum = checksum + SECTOR.rki[i];
        }
    SECTOR.rki[data_CRC] = checksum;
    }
}
//
//
void RAM_align(void) {
    switch(RK_Nr_old){
      //--------------------------------------------------------------
      case 0: {                                         // from Unit 0
            rk0_head = head;                            //
            rk0_Old_head = Old_head;                    ///
            rk0_cnr = Cylinder_nr=0;                    ////
            rk0_Old_Cyl_nr = Old_Cyl_nr;                ///// save rk0
            switch(RK_Nr){                              // ***
            case 1:                                     //  to Unit 1
                head = rk1_head;
                Old_head = rk1_Old_head;
                Cylinder_nr = rk1_cnr;
                Old_Cyl_nr = rk1_Old_Cyl_nr;
                BASE = RK1_base;break;
            case 2:                                     //  to Unit 2
                head = rk2_head;
                Old_head = rk2_Old_head;
                Cylinder_nr = rk2_cnr;
                Old_Cyl_nr = rk2_Old_Cyl_nr;
                BASE = RK2_base;break;
            case 3:                                     //  to Unit 3
                head = rk1_head;
                Old_head = rk1_Old_head;
                Cylinder_nr = rk3_cnr;
                Old_Cyl_nr = rk1_Old_Cyl_nr;
                BASE = RK3_base;break;
          }
        }break;
       //---------------------------------------------------------
       case 1: {                                        // from unit 1
            rk1_head = head;                            //
            rk1_Old_head = Old_head;                    ///
            rk1_cnr = Cylinder_nr;                      ////
            rk1_Old_Cyl_nr = Old_Cyl_nr;                ///// save rk1
            switch(RK_Nr) {                             // ***
            case 0:                                     //  to Unit 0
                head = rk0_head;
                Old_head = rk0_Old_head;
                Cylinder_nr = rk0_cnr;
                Old_Cyl_nr = rk0_Old_Cyl_nr;
                BASE = RK0_base;break;
            case 2:                                     //  to Unit 2
                head = rk2_head;
                Old_head = rk2_Old_head;
                Cylinder_nr = rk2_cnr;
                Old_Cyl_nr = rk2_Old_Cyl_nr;
                BASE = RK2_base;break;
            case 3:                                     //  to Unit 3
                head = rk1_head;
                Old_head = rk1_Old_head;
                Cylinder_nr = rk3_cnr;
                Old_Cyl_nr = rk1_Old_Cyl_nr;
                BASE = RK3_base;break;
            }
        }break;
     //---------------------------------------------------------
     case 2: {                                        // from unit 2
        rk2_head = head;                              //
        rk2_Old_head = Old_head;                      ///
        rk2_cnr = Cylinder_nr;                        ////
        rk2_Old_Cyl_nr = Old_Cyl_nr;                  ///// save rk1
        switch(RK_Nr) {
            case 0:                                     //  to Unit 0
                head = rk0_head;
                Old_head = rk0_Old_head;
                Cylinder_nr = rk0_cnr;
                Old_Cyl_nr = rk0_Old_Cyl_nr;
                BASE = RK0_base;break;
            case 1:                                     //  to Unit 1
                head = rk1_head;
                Old_head = rk1_Old_head;
                Cylinder_nr = rk1_cnr;
                Old_Cyl_nr = rk1_Old_Cyl_nr;
                BASE = RK1_base;break;
            case 3:                                     //  to Unit 3
                head = rk3_head;
                Old_head = rk3_Old_head;
                Cylinder_nr = rk3_cnr;
                Old_Cyl_nr = rk3_Old_Cyl_nr;
                BASE = RK3_base;break;
            }
        }break;
    //---------------------------------------------------------
    case 3: {                                        // from unit 3
        rk3_head = head;                             //
        rk3_Old_head = Old_head;                     ///
        rk0_cnr = Cylinder_nr;                       ////
        rk3_Old_Cyl_nr = Old_Cyl_nr;                 ///// save rk1
        switch(RK_Nr) {
            case 0:                                     //  to Unit 0
                head = rk0_head;
                Old_head = rk0_Old_head;
                Cylinder_nr = rk0_cnr;
                Old_Cyl_nr = rk0_Old_Cyl_nr;
                BASE = RK0_base;break;
            case 1:                                     //  to Unit 1
                head = rk1_head;
                Old_head = rk1_Old_head;
                Cylinder_nr = rk1_cnr;
                Old_Cyl_nr = rk1_Old_Cyl_nr;
                BASE = RK1_base;break;
            case 2:                                     //  to Unit 2
                head = rk2_head;
                Old_head = rk2_Old_head;
                Cylinder_nr = rk2_cnr;
                Old_Cyl_nr = rk2_Old_Cyl_nr;
                BASE = RK2_base;break;
            }
        }break;
     //---------------------------------------------------------
    }
    //
    RK_Nr_old = RK_Nr;
    RK_match_old = RK_match;
}
//
//
//
//
//
//                                            §§§§§§§§§§§§§§§§§§§§§§§§§§
//                                            §§§§§§§    MAIN    §§§§§§§
//                                            §§§§§§§§§§§§§§§§§§§§§§§§§§
//
int main()
{ 
    //unsigned int pio;
    unsigned short int temp;
    mode    = 0x0000;
    //
    init_HW();
    //  
    while(priwhile == 0) {    // Primary while
        priwhile = 0;
        secwhile = 0;
        *(uint32_t *)PIO_1_addr = mode;
        //    
        printf("\n\r\x1B[2J");
        printf("        ********* RK05 disk EMULATOR @ Soc/HPS *********               \n\r");
        printf("        **** DE10-Nano baed emulator Version V.1.0 *****               \n\r");
        printf("        ***********************|************************               \n\r");
        printf("                     (c) WWW.PDP11GY.COM                               \n\r");
        //
        startup_leds(); 
        SDRAM = 3342336;
        MAXCYL = RK05_size;
        strcpy( myfile2, "rk05-x.dec" );
        printf ("\n\r              >>>>> Device Type = RK05 <<<<");       //
        PRESET_one_SECTOR();
        make_rk_structure_in_ram();
        //
        // >>>> Check and setup available configured units <<<<<
        RK_unit = *(uint32_t *)PIO_1_addr;
        //RK_unit = *(uint32_t *)PIO_1_addr >>4  & ~0xFFF0;
        RK_unit = *(uint32_t *)PIO_1_addr & ~0xFFF0;
        printf ("\n\r     Configurated RK05 Unit(s): ");
        if (RK_unit & 0x0001) {
            printf ("RK0: ");
            rk0=1; }        
        if(RK_unit & 0x0002) {
            printf ("RK1: ");
            rk1=1; }
        if(RK_unit & 0x0004) {
            printf ("RK2: ");
            rk2=1; }
        if(RK_unit & 0x0008) {
            printf ("RK3: ");
            rk3=1; }
        fflush(stdout);
        //
        //
        // if no unit is selected: init disk sets
        if( RK_unit == 0 ) {
            format = 1; 
            printf("\n\r\n\n\n");
            printf("\n\r                 Inizialize new RK05 disk set.");
            printf("\n\r  To continue, set one of the slide switches in the on position.\n\r");
            fflush(stdout);
            while(RK_unit == 0) {
                RK_unit = *(uint32_t *)PIO_1_addr & ~0xFFF0;
            }
            printf("\n\r");
            printf ("      Construct RK05 cartridge format in RAM");
            fflush(stdout);
            make_rk_structure_in_ram();
            usleep( 50*1000 );
            printf ("\r\n     Clone RK0-RAM area to: ");
            printf ("RK1:  ");
            memcpy(&RKDRIVE.rk_drive_i[RK1_base], &RKDRIVE.rk_drive_i[BASE], SDRAM );
            usleep( 50*1000 );
            printf ("RK2:  ");
            memcpy(&RKDRIVE.rk_drive_i[RK2_base], &RKDRIVE.rk_drive_i[BASE], SDRAM );
            usleep( 50*1000 );
            printf ("RK3:  ");
            memcpy(&RKDRIVE.rk_drive_i[RK3_base], &RKDRIVE.rk_drive_i[BASE], SDRAM );
            usleep( 50*1000 );
            //
            printf ("\r\n     Dump RAM to SD-Card into file:");
            PRESET_one_SECTOR();
            WRITE_to_SD_Card(); 
            format=0;  
            printf ("\r\n\n Restart RK05 emulator \n\r\n");
            fflush(stdout);
            exit(0);
        }
        //
        //
        READ_from_SD_Card();
        //
        // >>>> Get current used cylinder  <<<<<
        Cylinder_nr =  *(uint32_t *)PIO_1_addr >>8 & ~0xFF00;
        Old_Cyl_nr = Cylinder_nr;
        printf ("\n\r     CYLINDER = %d ",Cylinder_nr );
        fflush(stdout);
        //
        mode = 0x0001;
        *(uint32_t *)PIO_1_addr = mode;                               // set interface enable
        //
        //*************************************************************************************
        //                              DEBUG Mode        
        if (~*(uint32_t *)PIO_0_addr & 0x4000 ) {           //  Button_2  @ I_ctrl[14]   ?
            printf("\n\r\n*********************************************");
            printf("\n\rDebug Mode: connect GPIO1, Pin 35 to PIN 20 ");
            printf("\n\r*********************************************\n\r\n\n");
            *(uint32_t *)PIO_1_addr = (mode=mode|0x0100);
            while(~*(uint32_t *)PIO_0_addr & 0x4000);      // wait until Button_2 = released
        }
        //***********************************************************************************           
        //
        //                                                             ##################
        WRITE_drive_to_FPGA(RAM_Address );//                           ### RAM-->FPGA ###
        //                                                             ##################
        //
        //
        //
        //
        //
        //                           §§§§§§§§§§§§§§§§§§§§§§§§§§
        //                           §§§§§§§  MAIN LOOP §§§§§§§
        //                           §§§§§§§§§§§§§§§§§§§§§§§§§§
        //
        while(secwhile == 0) {                     // Secondary while   
            // 1)Check if Unit-Number has been changed      AND                       =============1=============
            //   Check if new/changed Unit-Number is also configured
            //RK_match = (*(uint32_t *)PIO_1_addr >> 8) &~ 0xFFF0;
			RK_match = (*(uint32_t *)PIO_1_addr >> 4) &~ 0xFFF0;
            if((RK_match != RK_match_old) & ((RK_unit & RK_match) == RK_match)) {
                *(uint32_t *)PIO_1_addr =  (mode=mode | 0x0010);                    // Set drive to NOT ready @O_ctrl[4]
                RK_drive_nr_changed=TRUE;                                           // indicate 
                //
                //get new Unit-Number
                switch(RK_match) {
                    case 0x0001: RK_Nr = 0; break;
                    case 0x0002: RK_Nr = 1; break;
                    case 0x0004: RK_Nr = 2; break;
                    case 0x0008: RK_Nr = 3; break;
                }
                if(DEBUG == TRUE) {
                    printf("\n\r*********************************************");
                    printf("\n\r****  Current RAM_Address =   %d ", RAM_Address );
                    printf("\n\r****  Switch Unit Number from  %d ", RK_Nr_old );
                    printf(" to %d   **** ", RK_Nr ); 
                }           
                READ_drive_from_FPGA(RAM_Address);                               // Save FPGA/DPR into RAM
                RAM_align();
                RAM_Address = (Cylinder_nr * CYL_size) + head + BASE;            // Calculate new RAM Address
				//
                //                                                               // ##################
                WRITE_drive_to_FPGA(RAM_Address);                                // ### RAM-->FPGA ###
                //                                                               // ##################                                    // Write RAM-part to FPGA/DPR
                if(DEBUG == TRUE) {
                    printf("\n\r****  New RAM address : %d", RAM_Address);
                    printf("\n\r*********************************************");
                    fflush(stdout);
                }           
            } // ================================================================================================
            //
            //
            //
            // 2) check for drive command @ I_ctrl[1]                                 =============2=============
            //
            Cylinder_nr =  *(uint32_t *)PIO_1_addr >>8 & ~0xFF00;                // get Cylinder
            head        =  *(uint32_t *)PIO_0_addr & 0x0001;
            if ( (Cylinder_nr != Old_Cyl_nr)| (head != Old_head)) {              // Cylinder and/or head change
                //
                //                                                               // ##################
                READ_drive_from_FPGA(Old_RAM_Address);                           // ### FPGA-->RAM ###
                //                                                               // ##################
                //            
                if(head != Old_head){                                            // head change
                    printf("\n\r    head change to   ");
                    if( head == 0 ) {
                        printf("head 0 ");
                    }else{
                        printf("head 1 ");
                    }
                    temp = CYL_size/2 * head;                                    // !!!!! head-Offset
                    Old_head = head;    
                }else{
                    temp=0;
                    printf("\n\r");
                }
                if(Cylinder_nr != Old_Cyl_nr){                                   // Cylinder chnge
                    RAM_Address = (Cylinder_nr * CYL_size) + temp + BASE;        // Calculate new
                    printf("and/or new Cylinder %d @ new address %d", Cylinder_nr, RAM_Address  );
                }else{
                    RAM_Address = (Old_Cyl_nr * CYL_size) + temp + BASE;        // only head-change
                    printf(" @ new address  %d", RAM_Address);
                }           
                fflush(stdout);
                //
                //                                                              // ##################
                WRITE_drive_to_FPGA(RAM_Address);                               // ### RAM-->FPGA ###
                //                                                              // ##################
                //
                Old_head  = head;                                               // Save
                Old_Cyl_nr = Cylinder_nr;                                       // Save
                Old_RAM_Address = RAM_Address;                                  // Save
                //
                acknowledge();                                                  // All done ...indicate             

            }
            //
            //
            //
            // 3) check for RECONFIG request.                                         =============3=============
            if ( ~ *(uint32_t *)PIO_0_addr & 0x4000 ) {         //  Button_2  @ I_ctrl[14]   ? 
                usleep( 500*1000 );
                //while(*(uint32_t *)PIO_1_addr & 0x4000)
                RK_unit = (*(uint32_t *)PIO_1_addr >>4)  &~0xFFF0;
                printf ("\n\r\n Reconfigurated RK05 Unit(s): ");
                if(RK_unit & 0x0001) {
                   printf ("RK0: ");
                   rk0=1;
                }
                if(RK_unit & 0x0002) {
                    printf ("RK1: ");
                    rk1=1;
                }
                if(RK_unit & 0x0004) {
                    printf ("RK2: ");
                    rk2=1;
                }
                if(RK_unit & 0x0008) {
                    printf ("RK3: ");
                    rk3=1;
                }
            printf ("\n\n\r");
            }
            //
            //
            //
            //            // 4) check for power fail or reset                         =============4=============
            if (( ~ *(uint32_t *)PIO_0_addr & 0x8000 ) | ( ~ *(uint32_t *)PIO_1_addr & 0x0001 )) {
                if( OFFLINE == FALSE ) {   
                    printf("    Key[1] / Power-fail   \n\r");
                    usleep( 500*1000 );
                    printf("\x1B[2J\n\r\x07        ......... Shutting down system .........\n\r");
                    //READ_drive_from_FPGA(Old_RAM_Address);
                    Old_Cyl_nr = 0;
                    //....save
                    //WRITE_to_SD_Card();                    
                    *(uint32_t *)PIO_0_addr = 0x0000;                        // Clear PIO-0
                    *(uint32_t *)PIO_1_addr = 0x000C;                        // Clear PIO-1
                } else {
                    *(uint32_t *)PIO_0_addr = 0x0000;                        // Clear PIO-0
                    *(uint32_t *)PIO_1_addr = 0x000C;                        // Clear PIO-1
                    printf("\x07\n\n\r        *** System switched down *** \n\r"); 
                }
                secwhile = 1;               
            } 

        }  // Secondary while
        while ( ~ *(uint32_t *)PIO_0_addr & 0x8000 );   // Reset/Exit,       = Button 1 released
        usleep( 500*1000 );
        while ( ~ *(uint32_t *)PIO_0_addr & 0x4000 );   // Reconfig/Restart, = Button 2 released
        usleep( 500*1000 );
        printf("\x07\n\n\r  Press RESET/Button-1 for exit, Reconfig/Button-2 for restart  \n\r");
        priwhile = 2;
        while(priwhile == 2) {
            if ( ~ *(uint32_t *)PIO_0_addr & 0x4000 ) {  // Reconfig/Restart
                usleep( 500*1000 );
                secwhile = 0;
                priwhile = 0;
            }
            if ( ~ *(uint32_t *)PIO_0_addr & 0x8000 ) {  // Reset/EXit
                printf("\x07\n\n\r    Servus & Bye\n\r\n");
                fflush(stdout);
                usleep( 500*1000 );
                secwhile = 1;
                priwhile = 1;
            }
        }   
    } // Primary while
    return 0; 
}
